<?php namespace Darryldecode\Cart;

/**
 * Created by PhpStorm.
 * User: darryl
 * Date: 1/15/2015
 * Time: 9:46 PM
 */

use Illuminate\Support\Collection;

class CartConditionCollection extends Collection {

}